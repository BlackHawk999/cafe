import Vue from "vue";
import store from "@/store";
import axios from "axios";

import { EventBus } from "@/event-bus";

const host = "https://next2.fbuilder.webresto.dev/api";

const gitCredentials = "gitlab+deploy-token-12:eEnAT5GzA4mXcXywVxWs";

const instance = axios.create({
  baseURL: host,
  headers: { "Content-Type": "application/json" }
});

export const auth = async (repConf = store.state.repConf) => {
  try {
    const response: any = await instance.post("/auth", repConf);
    /* response = JSON.parse(response); */
    store.dispatch("setToken", response.data.token);
    store.dispatch("setPort", response.data.port);
    console.log(response);
    return response;
  } catch (error) {
    console.error(error);
  }
};

export const rebuild = async config => {
  config = { ...config };
  console.log(store.state.repConf);
  const aliasKey = Object.keys(store.state.repConf.aliases).find(el =>
    config.unit.includes(el)
  );
  config.aliases = {};
  config.aliases[aliasKey as string] =
    store.state.repConf.aliases[aliasKey as string];
  Object.keys(config.inventory).forEach(el => {
    console.log(config.inventory[el]);
    config.inventory[el].unit = aliasKey + "/" + config.inventory[el].unit;
  });
  store.commit("setBuildState", true);
  Vue.$toast.open({
    message: "Rebuild statrted",
    type: "info"
    // all of other options may go here
  });
  try {
    const response: any = await instance.post("/rebuild", config, {
      headers: {
        "X-Session-Token": store.state.token
      }
    });
    console.log(response);
    store.commit("setBuildState", false);
    Vue.$toast.open({
      message: "Rebuild ended",
      type: "success"
      // all of other options may go here
    });
    return response;
  } catch (error) {
    store.commit("setBuildState", false);
    Vue.$toast.open({
      message: "Rebuild failed",
      type: "error"
      // all of other options may go here
    });
    console.error(error);
    return error;
  }
};

export const getSession = async () => {
  try {
    const response = await instance.get("/session", {
      headers: {
        "X-Session-Token": store.state.token
      }
    });
    store.dispatch("setPort", response.data.port);
    console.log(response);
    return response;
  } catch (error) {
    console.error(error);
    return error;
  }
};

export const getLayouts = async () => {
  try {
    const response = await instance.get("/layouts", {
      headers: {
        "X-Session-Token": store.state.token
      }
    });
    console.log(response);
    store.dispatch("setLayouts", response.data);
    return response;
  } catch (error) {
    console.error(error);
    return error;
  }
};

export const getComponentsBySlug = async (slug: string) => {
  try {
    const response = await instance.get(`components?layout=${slug}`, {
      headers: {
        "X-Session-Token": store.state.token
      }
    });
    console.log(response);
    store.dispatch("setComponents", response.data);
    return response;
  } catch (error) {
    console.error(error);
    return error;
  }
};

/* const websocket = new WebSocket("wss://staging.fbuilder.webresto.dev/ws");

const socketInit = (): void => {
  websocket.addEventListener("open", function(event) {
    websocket.send(
      JSON.stringify({
        type: "auth",
        token:
          "32fjdusajfn328ndsf8sdfnsa7ucx2n1lk3j21h3219783dasn238127312nmdsa23"
      })
    );
    Vue.$toast.open({
      message: "Successful connection to websocket!",
      type: "success"
      // all of other options may go here
    });
    websocket.send(
      JSON.stringify({
        type: "getTemplates"
      })
    );
  });

  websocket.addEventListener("error", error => {
    console.log(error)
    Vue.$toast.open({
      message: "connection error to websocket",
      type: "error"
      // all of other options may go here
    });
  });

  websocket.addEventListener("message", function(event) {
    const json_data = JSON.parse(event.data);
    console.log(json_data);
    switch (json_data["type"]) {
      case "config":
        store.dispatch("setConfig", json_data);
        console.log("Got config request!", json_data);
        break;
      case "units":
        store.dispatch("setLayouts", json_data.data);
        break;
      case "template":
        store.dispatch("setComponents", json_data.template);
        break;
      case "error":
        console.log("[Error] " + json_data["errorMessage"]);
        break;
      case "log":
        console.log("[Log] " + json_data["logData"]);
        break;
    }
  });
};

const sendConfig = (json: JSON): void => {
  websocket.send(
    JSON.stringify(
      {
        type: "newConfig",
        data: json
      },
      null,
      0
    )
  );
};

const getTemplateBySlug = (slug: string): void => {
  store.dispatch("setComponents", null);
  websocket.send(
    JSON.stringify({
      type: "getTemplateBySlug",
      slug
    })
  );
};

export { socketInit, sendConfig, getTemplateBySlug }; */
