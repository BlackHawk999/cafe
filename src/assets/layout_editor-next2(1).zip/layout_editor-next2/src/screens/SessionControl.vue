<template>
  <v-container class="">
    <v-row justify="center">
      <Jsoneditor @setJson="setRepConf" :ObjectJson="getRepConf"></Jsoneditor>
    </v-row>
  </v-container>
</template>

<script lang="ts">
import Vue from "vue";
import Jsoneditor from "@/components/Jsoneditor.vue";
import { auth, rebuild } from "../services/api";
import { mapGetters, mapActions, mapMutations } from "vuex";
export default Vue.extend({
  data() {
    return {};
  },
  components: {
    Jsoneditor
  },
  methods: {
    ...mapActions(["setRepConfig"]),
    ...mapMutations({
      addReceipt: "setReceipt",
      clearReceipts: "clearReceipts"
    }),
    async setRepConf(conf) {
      this.setRepConfig(conf);
      Vue.$toast.open({
        message: "смена конфига началась",
        type: "success"
        // all of other options may go here
      });
      await auth();
      this.clearReceipts();
      this.addReceipt({
        receipt: {
          unit: "base_layouts/layout1",
          name: "default",
          createdAt: new Date(),
          aliases: {
            base_layouts: {
              git:
                "https://{$CREDENTIALS}@git.hm/webresto/factory/base_layouts.git",
              rev: "staging"
            }
          },
          constant: {
            cssVariables: {},
            states: {},
            variables: {}
          },
          fonts: {},
          inventory: {}
        }
      });
      this.$router.push({ path: "/" });
      Vue.$toast.open({
        message: "Конфиг репозиториев сохранен",
        type: "success"
        // all of other options may go here
      });
      await rebuild(this.getReceipts[0]);
    }
  },
  computed: {
    // mix the getters into computed with object spread operator
    ...mapGetters([
      "getRepConf",
      "getReceipts"
      // ...
    ])
  }
});
</script>

<style></style>
