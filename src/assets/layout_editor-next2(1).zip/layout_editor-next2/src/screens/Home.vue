<template>
  <v-container class="grey home-container" fluid>
    <!-- If using vue-router -->
    <v-responsive
      class="ml-auto mr-auto"
      :height="height"
      :width="width"
      :aspect-ratio="ratio"
    >
      <v-progress-linear
        indeterminate
        v-if="getBuildState"
        color="yellow darken-2"
      ></v-progress-linear>
      <iframe
        v-show="!getBuildState"
        ref="iframe"
        id="frame"
        width="100%"
        height="100%"
      ></iframe>
    </v-responsive>
  </v-container>
</template>

<script lang="ts">
import Vue from "vue";
import { mapGetters } from "vuex";
import { deviceType } from "@/types/";

export default Vue.extend({
  data() {
    return {
      width: "100%",
      height: "100vh",
      ratio: "16 / 9",
    };
  },
  computed: {
    // mix the getters into computed with object spread operator
    ...mapGetters([
      "deviceType",
      "getPort",
      "getBuildState",
      // ...
    ]),
  },
  watch: {
    deviceType: {
      deep: true,
      handler(newDevice) {
        this.setSize(newDevice);
      },
    },
    getBuildState(newBuildState) {
      if (!newBuildState) {
        this.loadFrame(this.getPort);
      }
    },
  },
  methods: {
    loadFrame(port): void {
      let myFrame = this.$refs.iframe as HTMLInputElement;
      myFrame.src = `https://next.fbuilder.webresto.dev/preview/${port}/menu`;
    },
    setSize(device: deviceType): void {
      if (device === "tablet") {
        this.width = "768px";
        this.height = "1024px";
        this.ratio = "4 / 3";
      } else if (device === "mobile") {
        this.width = "375px";
        this.height = "812px";
        this.ratio = "13/6";
      } else {
        this.width = "100%";
        this.height = "100vh";
        this.ratio = "16 / 9";
      }
    },
  },
});
</script>

<style lang="scss">
.home-container {
  min-height: 100%;
}
</style>