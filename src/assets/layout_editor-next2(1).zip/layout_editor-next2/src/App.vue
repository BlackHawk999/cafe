<template>
  <v-app>
    <Header></Header>

    <v-main>
      <!-- Provides the application the proper gutter -->
      <router-view></router-view>
    </v-main>
  </v-app>
</template>

<script lang="ts">
import Vue from "vue";
import { Header } from "@/components"; // @ is an alias to /src
import { mapGetters, mapMutations } from "vuex";
import { auth, getLayouts, getSession, rebuild } from "@/services/api";

export default Vue.extend({
  components: { Header },
  async mounted() {
    if (!this.getToken) {
      await auth();
      this.addReceipt({
        receipt: {
          unit: "base_layouts/layout1",
          name: "default",
          createdAt: new Date(),
          aliases: {
            base_layouts: {
              git: "https://{$CREDENTIALS}@git.hm/webresto/factory/base_layouts.git",
              rev: "staging",
            },
          },
          constant: {
            cssVariables: {},
            states: {},
            variables: {},
          },
          fonts: {
          },
          inventory: {},
        },
      });
    }
    const data = await getSession();
    if (data.response && data.response.status == 403) {
      await auth();
    }
    await getLayouts();
    await rebuild(
      this.getReceipts[0]
    );
  },
  computed: {
    // mix the getters into computed with object spread operator
    ...mapGetters([
      "getToken",
      "getReceipts",
      // ...
    ]),
  },
  methods: {
    ...mapMutations({
      addReceipt: "setReceipt",
    }),
  },
});
</script>

<style lang="scss">
@import "~vuetify/dist/vuetify.min.css";
#app {
  font-family: Roboto, sans-serif; /* this was it */
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #333;
}
</style>
