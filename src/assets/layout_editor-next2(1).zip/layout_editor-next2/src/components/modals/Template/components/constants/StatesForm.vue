<template>
  <v-row>
    <v-col
      v-for="state in states"
      :key="state.name"
      class="d-flex flex-column"
      cols="6"
    >
      <div class="d-flex justify-space-between">
        <v-switch
          v-model="statesReference[state.key]"
          @change="handleState"
          :label="state.name"
          v-if="state.type === 'boolean'"
        ></v-switch>
        <v-select
          v-if="state.type === 'enum'"
          v-model="statesReference[state.key]"
          :items="state.enum.map(el => el.name)"
        >
        </v-select>
        <v-text-field
          @input="handleState"
          v-model="statesReference[state.key]"
          v-if="!state.type"
          :label="state.name"
        ></v-text-field>
        <v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }">
            <v-btn v-bind="attrs" v-on="on" class="ma-2"  icon>
              <v-icon dark>mdi-cloud-question </v-icon>
            </v-btn>
          </template>
          <span>{{ state.description }}</span>
        </v-tooltip>
      </div>
    </v-col>
  </v-row>
</template>

<script lang="ts">
import Vue from "vue";
export default Vue.extend({
  props: ["states", "statesReference"],
  methods: {
    handleState() {
      console.log(this.statesReference);
    },
  },
});
</script>

<style>
</style>