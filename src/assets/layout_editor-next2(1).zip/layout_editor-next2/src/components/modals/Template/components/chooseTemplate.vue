<template>
  <v-container fluid>
    <v-row justify="space-around">
      <v-col cols="5">
        <div>
          <v-select v-model="layout" :items="layoutsSlugs"></v-select>
        </div>
        <div>
          <p class="body-2 text-left">
            {{ getLayoutBySlug(layout).unit.description }}
          </p>
        </div>
      </v-col>
      <v-col offset="2" cols="5">
        <v-img
          lazy-src="https://picsum.photos/id/11/10/6"
          max-height="284"
          max-width="389"
          src="https://picsum.photos/id/11/500/300"
        ></v-img>
      </v-col>
    </v-row>
    <v-row justify="end">
      <v-btn
        @click="setTemplate"
        color="purple"
        depressed
        elevation="2"
        medium
        class="white--text"
        >Выбрать</v-btn
      >
    </v-row>
  </v-container>
</template>

<script lang="ts">
import Vue from "vue";
export default Vue.extend({
  mounted() {
    console.log(this.layouts);
  },
  data() {
    return {
      layoutsSlugs: (this as any).getLayoutsSlugs(),
      layout: (this as any).getLayoutsSlugs()[0],
    };
  },
  props: ["layouts"],
  methods: {
    getLayoutsSlugs() {
      const layoutsSlugs = Object.keys(this.layouts).map((el) => {
        return this.layouts[el].unit.slug;
      });
      return layoutsSlugs;
    },
    getLayoutBySlug(slug) {
      let layout 
      Object.keys(this.layouts).forEach(el => {
        if(this.layouts[el].unit.slug == slug) {
          layout = this.layouts[el]
        }
      })
      console.log(layout);
      return layout;
    },
    setTemplate() {
       this.$emit("layoutSelected", this.layout)
    },
  },
});
</script>

<style lang="scss">
</style>