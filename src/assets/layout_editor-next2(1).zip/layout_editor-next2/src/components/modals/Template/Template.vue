<template>
  <v-row class="mt-10" justify="end" align="center">
    <v-dialog class="white" v-model="tempalte" width="80vw">
      <template v-slot:activator="{ on, attrs }">
        <v-btn
          depressed
          color="primary"
          v-bind="attrs"
          v-on="on"
          href=""
          :class="{ 'grey--text lighten-5': hover }"
          class="text-body-2 text-decoration-none white--text"
          >Создать рецепт</v-btn
        >
      </template>
      <div class="modal__wrapper">
        <v-btn class="close" @click="tempalte = !tempalte" icon color="grey">
          <v-icon>mdi-close</v-icon>
        </v-btn>
        <v-card class="mb-5">
          <v-tabs v-model="tab">
            <v-tab>visual</v-tab>
            <v-tab>json</v-tab>
          </v-tabs>
        </v-card>

        <v-card class="modal-tab">
          <v-tabs-items v-model="tab">
            <v-tab-item>
              <h2 class="text-left my-5">Создание рецепта сайта</h2>
              <!-- Comment for choosing layout -->
              <chooseTemplate
                class="mb-7"
                v-if="getLayouts"
                @layoutSelected="setTemplate"
                :layouts="getLayouts"
              ></chooseTemplate>
              <transition name="fade">
                <template v-if="config.unit">
                  <v-container fluid>
                    <v-row>
                      <v-text-field
                        label="Название рецепта"
                        hide-details="auto"
                        :rules="rules"
                        v-model="config.name"
                      ></v-text-field>
                    </v-row>
                    <v-row class="d-flex flex-column mt-10">
                      <h3 class="text-h6 text-left">Шрифт</h3>
                      <div class="">
                        <Fonts
                          :fonts="layoutConfig.component.availableFonts"
                          :fontsReference="config.fonts"
                          :fontsConfig="layoutConfig.component.fonts"
                        ></Fonts>
                      </div>
                    </v-row>
                    <v-row class="d-flex flex-column mt-10">
                      <h3 class="text-h6 text-left">Состояния</h3>
                      <statesForm
                        :states="layoutConfig.component.constant.states"
                        :statesReference="config.constant.states"
                      ></statesForm>
                    </v-row>
                    <v-row class="d-flex flex-column mt-10">
                      <h3 class="text-h6 text-left">Переменные</h3>
                      <statesForm
                        :states="layoutConfig.component.constant.variables"
                        :statesReference="config.constant.variables"
                      ></statesForm>
                    </v-row>
                    <v-row class="mt-15">
                      <v-col cols="12">
                        <h3 class="text-h6 text-left">Cочетание цветов</h3>
                      </v-col>
                      <v-col cols="12">
                        <colorForm
                          :colors="layoutConfig.component.constant.cssVariables"
                          :colorsReference="config.constant.cssVariables"
                        ></colorForm>
                      </v-col>
                    </v-row>
                    <v-expansion-panels>
                      <v-expansion-panel
                        v-for="item in components"
                        :key="item.message"
                        class="mt-15"
                        :set="(compArr = componentsForInventory(item))"
                      >
                        <v-expansion-panel-header class="text-h6 text-left">
                          {{ compArr[0].unit.name }}
                        </v-expansion-panel-header>
                        <v-expansion-panel-content>
                          <chooseComponent
                            @setComponent="setComponent"
                            :availabelComponents="compArr"
                          ></chooseComponent>
                          <transition name="fade">
                            <div
                              :set="
                                (selectedComponent = getSelectedComponent(
                                  compArr,
                                  config.inventory[compArr[0].unit.type].unit
                                ))
                              "
                              v-if="
                                config.inventory[compArr[0].unit.type] &&
                                config.inventory[compArr[0].unit.type].unit
                              "
                            >
                              <v-col
                                v-if="
                                  selectedComponent.component.availableFonts
                                    .length > 0
                                "
                                cols="12"
                              >
                                <h4>Шрифт</h4>
                                <Fonts
                                  :fonts="
                                    selectedComponent.component.availableFonts
                                  "
                                  :fontsReference="config.fonts"
                                  :fontsConfig="
                                    selectedComponent.component.fonts
                                  "
                                ></Fonts>
                              </v-col>
                              <v-col
                                v-if="
                                  selectedComponent.component.constant.states
                                    .length > 0
                                "
                                cols="12"
                              >
                                <h4 class="text-h6 text-left">Состояния</h4>
                                <statesForm
                                  :states="
                                    selectedComponent.component.constant.states
                                  "
                                  :statesReference="
                                    config.inventory[
                                      selectedComponent.unit.type
                                    ].constant.states
                                  "
                                ></statesForm>
                              </v-col>
                              <v-col
                                v-if="
                                  selectedComponent.component.constant.variables
                                    .length > 0
                                "
                                cols="12"
                              >
                                <h4 class="text-h6 text-left">Переменные</h4>
                                <statesForm
                                  :states="
                                    selectedComponent.component.constant
                                      .variables
                                  "
                                  :statesReference="
                                    config.inventory[
                                      selectedComponent.unit.type
                                    ].constant.variables
                                  "
                                ></statesForm>
                              </v-col>
                              <v-row class="mt-15">
                                <v-col cols="12">
                                  <h3 class="text-h6 text-left">
                                    Cочетание цветов
                                  </h3>
                                </v-col>
                                <v-col cols="12">
                                  <colorForm
                                    :colors="
                                      selectedComponent.component.constant
                                        .cssVariables
                                    "
                                    :colorsReference="
                                      config.inventory[
                                        selectedComponent.unit.type
                                      ].constant.cssVariables
                                    "
                                  ></colorForm>
                                </v-col>
                              </v-row>
                            </div>
                          </transition>
                        </v-expansion-panel-content>
                      </v-expansion-panel>
                    </v-expansion-panels>
                  </v-container>
                </template>
              </transition>
              <v-container class="mt-5" fluid v-if="components.length > 0">
                <v-row justify="end">
                  <v-btn
                    color="purple"
                    depressed
                    elevation="2"
                    medium
                    class="white--text"
                    @click="onSave"
                    >Применить рецепт</v-btn
                  >
                </v-row>
              </v-container>
            </v-tab-item>
            <v-tab-item>
              <Jsoneditor
                :key="componentKey"
                @setJson="setConfigJson"
                v-if="config"
                :ObjectJson="config"
              ></Jsoneditor>
            </v-tab-item>
          </v-tabs-items>
        </v-card>
      </div>
    </v-dialog>
  </v-row>
</template>

<script lang="ts">
import Vue from "vue";
import { mapGetters, mapMutations } from "vuex";
import Jsoneditor from "@/components/Jsoneditor.vue";
import chooseTemplate from "@/components/modals/Template/components/chooseTemplate.vue";
import chooseComponent from "@/components/modals/Template/components/chooseComponent.vue";
import { getComponentsBySlug, rebuild } from "@/services/api";
import Fonts from "@/components/modals/Template/components/constants/Fonts.vue";
import statesForm from "@/components/modals/Template/components/constants/StatesForm.vue";
import colorForm from "@/components/modals/Template/components/constants/ColorForm.vue";
export default Vue.extend({
  name: "Template",
  components: {
    Jsoneditor,
    chooseTemplate,
    Fonts,
    statesForm,
    colorForm,
    chooseComponent,
  },
  data(): any {
    return {
      // The value represent if modal is open
      tempalte: false,
      // The number of opened tab
      tab: null,
      componentKey: 0,
      components: [],
      rules: [
        (value) => !!value || "Required.",
        (value) => (value && value.length >= 3) || "Min 3 characters",
      ],
      config: {
        unit: "",
        description: "",
        constant: {
          cssVariables: {},
          states: {},
          variables: {},
        },
        fonts: {
        },
        iconSet: [],
        inventory: {},
      },
      layoutConfig: {},
    };
  },
  computed: {
    // mix the getters into computed with object spread operator
    ...mapGetters([
      "getLayouts",
      "getComponents",
      // ...
    ]),
  },
  watch: {
    getComponents(newValue) {
      this.components = [];
      Object.keys(newValue).forEach((el) => {
        this.components.push(newValue[el]);
      });
    },
  },
  methods: {
    ...mapMutations({
      addReceipt: "setReceipt",
    }),
    onSave() {
      if (!this.config.name) {
        Vue.$toast.open({
          message: "рецепту необходимо дать имя",
          type: "error",
          // all of other options may go here
        });
        return;
      }
      this.config.createdAt = new Date();
      this.addReceipt({receipt: this.config});
      rebuild(this.config);
      this.clearConf();
      this.tempalte = false
    },
    clearConf() {
      this.config = {
        unit: "",
        description: "",
        constant: {
          cssVariables: {},
          states: {},
          variables: {},
        },
        fonts: {
          main: "",
          secondary: "",
        },
        iconSet: [],
        inventory: {},
      };
      this.layoutConfig = {};
    },
    getSelectedComponent(compArr, slug) {
      return compArr.find((el) => el.unit.slug === slug);
    },
    componentsForInventory(obj) {
      const arr: Array<any> = [];
      Object.keys(obj).forEach((key) => {
        arr.push(obj[key]);
      });
      return arr;
    },
    async setTemplate(layout) {
      console.log(layout);
      await getComponentsBySlug(this.getLayoutKeyBySlug(layout));
      this.layoutConfig = this.getLayoutBySlug(layout);
      this.config.unit = this.getLayoutKeyBySlug(layout);
      this.config.description = this.layoutConfig.unit.description;
      this.config.fonts.main = this.layoutConfig.component.fonts.main.default;
      this.config.fonts.secondary =
        this.layoutConfig.component.fonts.secondary.default;
      this.config.iconSet = this.layoutConfig.component.iconSet;
      console.log(this.config);
    },
    getLayoutKeyBySlug(layout) {
      console.log(layout);
      //index of selected layout
      let index;
      Object.keys(this.getLayouts).forEach((el, i) => {
        console.log(this.getLayouts[el]);
        if (this.getLayouts[el].unit.slug === layout) {
          index = i;
        }
      });

      return Object.keys(this.getLayouts)[index];
    },
    getLayoutBySlug(layout) {
      console.log(layout);
      //index of selected layout
      let layoutConf;
      Object.keys(this.getLayouts).forEach((el) => {
        console.log(this.getLayouts[el]);
        if (this.getLayouts[el].unit.slug === layout) {
          layoutConf = this.getLayouts[el];
        }
      });

      return layoutConf;
    },
    setComponent({ componentName, type }) {
      this.config.inventory[type] = {
        unit: "",
        constant: {
          cssVariables: {},
          states: {},
          variables: {},
        },
      };
      this.config.inventory[type].unit = componentName;
      /* this.config = { ...this.config }; */
      console.log(this.config);
      this.forceRerender();
    },
    forceRerender() {
      this.componentKey += 1;
    },
    setConfigJson(json) {
      console.log(json);
      this.config = json;
      /* this.forceRerender(); */
    },
  },
});
</script>

<style lang="scss">
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}
.modal__wrapper {
  position: relative;
  background-color: #ffffff;
  padding: 3.4375rem 2.5rem 4.0625rem 2.5rem;
  .close {
    position: absolute;
    left: auto;
    right: 0.475rem;
    top: 0.675rem;
  }

  .modal-tab {
    box-shadow: none !important;

    .v-expansion-panel-header {
      font-size: 2rem;
      color: #191d32;
      font-weight: bold;
      &__icon {
        margin-left: 6px;
        .v-icon {
          color: #707584;
        }
      }
    }
  }
}
</style>
