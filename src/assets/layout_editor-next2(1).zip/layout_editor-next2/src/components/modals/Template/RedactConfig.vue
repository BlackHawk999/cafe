<template>
  <v-row justify="center" align="center">
    <v-dialog class="white" v-model="show" width="80vw">
      <template v-slot:activator="{ on, attrs }">
        <v-hover v-slot="{ hover }">
          <a
            @click.prevent
            v-bind="attrs"
            v-on="on"
            href=""
            :class="{ 'grey--text lighten-5': hover }"
            class="text-body-2 text-decoration-none white--text"
            >Редактировать рецепт</a
          >
        </v-hover>
      </template>
      <div class="modal__wrapper">
        <v-btn class="close" @click="show = !show" icon color="grey">
          <v-icon>mdi-close</v-icon>
        </v-btn>
        <h3 class="mb-5">Редактировать конфиг</h3>
        <v-card class="mb-5">
          <v-tabs v-model="tab">
            <v-tab>visual</v-tab>
            <v-tab>json</v-tab>
          </v-tabs>
        </v-card>
        <v-card class="modal-tab">
          <v-tabs-items v-model="tab">
            <v-tab-item>
              <transition name="fade">
                <template v-if="config.unit">
                  <v-container fluid>
                    <v-row>
                      <v-text-field
                        label="Название конфига"
                        hide-details="auto"
                        v-model="config.name"
                        disabled
                      ></v-text-field>
                    </v-row>
                    <v-row class="d-flex flex-column mt-10">
                      <h3 class="text-h6 text-left">Шрифт</h3>
                      <div class="">
                        <Fonts
                          :fonts="layoutConfig.component.availableFonts"
                          :fontsReference="config.fonts"
                          :fontsConfig="layoutConfig.component.fonts"
                        ></Fonts>
                      </div>
                    </v-row>
                    <v-row class="d-flex flex-column mt-10">
                      <h3 class="text-h6 text-left">Состояния</h3>
                      <statesForm
                        :states="layoutConfig.component.constant.states"
                        :statesReference="config.constant.states"
                      ></statesForm>
                    </v-row>
                    <v-row class="d-flex flex-column mt-10">
                      <h3 class="text-h6 text-left">Переменные</h3>
                      <statesForm
                        :states="layoutConfig.component.constant.variables"
                        :statesReference="config.constant.variables"
                      ></statesForm>
                    </v-row>
                    <v-row class="mt-15">
                      <v-col cols="12">
                        <h3 class="text-h6 text-left">Cочетание цветов</h3>
                      </v-col>
                      <v-col cols="12">
                        <colorForm
                          :colors="layoutConfig.component.constant.cssVariables"
                          :colorsReference="config.constant.cssVariables"
                        ></colorForm>
                      </v-col>
                    </v-row>
                    <v-expansion-panels>
                      <v-expansion-panel
                        v-for="item in components"
                        :key="item.message"
                        class="mt-15"
                        :set="(compArr = componentsForInventory(item))"
                      >
                        <v-expansion-panel-header class="text-h6 text-left">
                          {{ compArr[0].unit.name }}
                        </v-expansion-panel-header>
                        <v-expansion-panel-content>
                          <chooseComponent
                            @setComponent="setComponent"
                            :availabelComponents="compArr"
                            :selected="
                              config.inventory[compArr[0].unit.type]
                                ? config.inventory[compArr[0].unit.type].unit
                                : null
                            "
                          ></chooseComponent>
                          <transition name="fade">
                            <div
                              :set="
                                (selectedComponent = getSelectedComponent(
                                  compArr,
                                  config.inventory[compArr[0].unit.type].unit
                                ))
                              "
                              v-if="
                                config.inventory[compArr[0].unit.type] &&
                                config.inventory[compArr[0].unit.type].unit
                              "
                            >
                              <v-col
                                v-if="
                                  selectedComponent.component.availableFonts
                                    .length > 0
                                "
                                cols="12"
                              >
                                <h4>Шрифт</h4>
                                <Fonts
                                  :fonts="
                                    selectedComponent.component.availableFonts
                                  "
                                  :fontsReference="config.fonts"
                                  :fontsConfig="
                                    selectedComponent.component.fonts
                                  "
                                ></Fonts>
                              </v-col>
                              <v-col
                                v-if="
                                  selectedComponent.component.constant.states
                                    .length > 0
                                "
                                cols="12"
                              >
                                <h4 class="text-h6 text-left">Состояния</h4>
                                <statesForm
                                  :states="
                                    selectedComponent.component.constant.states
                                  "
                                  :statesReference="
                                    config.inventory[
                                      selectedComponent.unit.type
                                    ].constant.states
                                  "
                                ></statesForm>
                              </v-col>
                              <v-col
                                v-if="
                                  selectedComponent.component.constant.variables
                                    .length > 0
                                "
                                cols="12"
                              >
                                <h4 class="text-h6 text-left">Переменные</h4>
                                <statesForm
                                  :states="
                                    selectedComponent.component.constant
                                      .variables
                                  "
                                  :statesReference="
                                    config.inventory[
                                      selectedComponent.unit.type
                                    ].constant.variables
                                  "
                                ></statesForm>
                              </v-col>
                              <v-row class="mt-15">
                                <v-col cols="12">
                                  <h3 class="text-h6 text-left">
                                    Cочетание цветов
                                  </h3>
                                </v-col>
                                <v-col cols="12">
                                  <colorForm
                                    :colors="
                                      selectedComponent.component.constant
                                        .cssVariables
                                    "
                                    :colorsReference="
                                      config.inventory[
                                        selectedComponent.unit.type
                                      ].constant.cssVariables
                                    "
                                  ></colorForm>
                                </v-col>
                              </v-row>
                            </div>
                          </transition>
                        </v-expansion-panel-content>
                      </v-expansion-panel>
                    </v-expansion-panels>
                    <v-row class="mt-15" justify="end">
                      <v-btn
                        color="purple"
                        depressed
                        block
                        elevation="2"
                        medium
                        class="white--text"
                        @click="onChange"
                        >Изменить</v-btn
                      >
                    </v-row>
                  </v-container>
                </template>
              </transition>
            </v-tab-item>
            <v-tab-item>
              <Jsoneditor
                :key="componentKey"
                @setJson="setConfigJson"
                v-if="config"
                :ObjectJson="config"
              ></Jsoneditor>
            </v-tab-item>
          </v-tabs-items>
        </v-card>
      </div>
    </v-dialog>
  </v-row>
</template>

<script lang="ts">
import Vue from "vue";
import { mapGetters, mapMutations } from "vuex";
import Jsoneditor from "@/components/Jsoneditor.vue";
import { getComponentsBySlug, rebuild } from "@/services/api";
import chooseComponent from "@/components/modals/Template/components/chooseComponent.vue";
import Fonts from "@/components/modals/Template/components/constants/Fonts.vue";
import statesForm from "@/components/modals/Template/components/constants/StatesForm.vue";
import colorForm from "@/components/modals/Template/components/constants/ColorForm.vue";
export default Vue.extend({
  data(): any {
    return {
      componentKey: 0,
      show: false,
      tab: null,
      config: {},
      layoutConfig: {},
      components: [],
    };
  },
  components: {
    Jsoneditor,
    Fonts,
    statesForm,
    colorForm,
    chooseComponent,
  },
  props: {
    configName: {
      required: true,
      type: String,
    },
  },
  watch: {
    show(val) {
      if (val) {
        this.setConfig();
        console.log(this.config);
      }
    },
    getComponents(newValue) {
      this.components = [];
      Object.keys(newValue).forEach((el) => {
        this.components.push(newValue[el]);
      });
    },
  },
  computed: {
    // mix the getters into computed with object spread operator
    ...mapGetters([
      "getLayouts",
      "getComponents",
      "getReceipts",
      // ...
    ]),
  },
  methods: {
    ...mapMutations({
      addReceipt: "setReceipt",
    }),
    onChange() {
      this.config.createdAt = new Date()
      this.addReceipt({ receipt: this.config, action: "update" });
      rebuild(this.config)
      this.config = {};
      this.layoutConfig = {};
      this.components = [];
      this.show = false;
    },
    forceRerender() {
      this.componentKey += 1;
    },
    async setConfig() {
      const config = this.getReceipts.find((el) => el.name === this.configName);
      this.getLayoutByUnit(config.unit);
      await getComponentsBySlug(config.unit);
      this.config = config;
    },
    getLayoutByUnit(unit) {
      const key: any = Object.keys(this.getLayouts).find((el) => el === unit);
      this.layoutConfig = this.getLayouts[key];
      console.log(this.layoutConfig);
    },
    getSelectedComponent(compArr, slug) {
      return compArr.find((el) => el.unit.slug === slug);
    },
    setComponent({ componentName, type }) {
      this.config.inventory[type] = {
        unit: "",
        constant: {
          cssVariables: {},
          states: {},
          variables: {},
        },
      };
      this.config.inventory[type].unit = componentName;
      this.forceRerender();
      console.log(this.config);
    },
    setConfigJson(json) {
      console.log(json);
      this.config = json;
    },
    componentsForInventory(obj) {
      const arr: Array<any> = [];
      Object.keys(obj).forEach((key) => {
        arr.push(obj[key]);
      });
      return arr;
    },
  },
});
</script>

<style>
</style>