<template>
  <v-row justify="space-between">
    <v-col class="mt-5" cols="5">
      <div class="d-flex" v-for="item in this.colors" :key="item.name">
        <v-text-field
          v-model="selectedColors[item.key]"
          :label="item.name"
          @click="ColorChange(item.key);"
          readonly
        ></v-text-field>
        <v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }">
            <v-btn v-bind="attrs" v-on="on" class="ma-2" color="purple" dark>
              <v-icon dark>mdi-help-rhombus </v-icon>
            </v-btn>
          </template>
          <span>{{ item.description }}, default color is {{item.value}}</span>
        </v-tooltip>
      </div>
    </v-col>
    <v-col class="mt-5" offset="1" cols="5">
      <v-color-picker
        dot-size="25"
        mode="hexa"
        swatches-max-height="200"
        :disabled="disabled"
        @input="setColor"
      ></v-color-picker>
    </v-col>
  </v-row>
</template>

<script lang="ts">
import Vue from "vue";
export default Vue.extend({
  data() {
    return {
      key: "",
      disabled: true,
      colorsValue: { ...this.colors },
      selectedColors: {},
    };
  },
  props: ["colors", "colorsReference"],
  methods: {
    ColorChange(key) {
      this.key = key;
      this.disabled = false;
    },
    setColor(event) {
      this.colorsReference[this.key] = event.hexa;
      this.selectedColors = { ...this.colorsReference };
    },
  },
});
</script>

<style>
</style>