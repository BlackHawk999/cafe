<template>
  <v-container fluid>
    <v-row justify="space-around">
      <v-col cols="5">
        <div>
          <v-select
            v-model="component"
            :items="availabelComponents.map((el) => el.unit.slug)"
          >
          </v-select>
        </div>
        <div>
          <p class="body-2 text-left">
            {{ getComponentDescr(component) }}
          </p>
        </div>
      </v-col>
      <v-col offset="2" cols="5">
        <v-img
          lazy-src="https://picsum.photos/id/11/10/6"
          max-height="284"
          max-width="389"
          src="https://picsum.photos/id/11/500/300"
        ></v-img>
      </v-col>
    </v-row>
  <!--   <v-row justify="end">
      <v-btn
        @click="setComponent"
        color="purple"
        depressed
        elevation="2"
        medium
        :disabled="component === selected"
        class="white--text"
        >Выбрать</v-btn
      >
    </v-row> -->
  </v-container>
</template>

<script lang="ts">
import Vue from "vue";
export default Vue.extend({
  props: {
    availabelComponents: {
      required: true,
    },
    selected: {
      required: false,
    },
  },
  data():any {
    return {
      component: "",
    };
  },
  mounted () {
    if(this.selected) {
      this.component = this.selected 
    }
  },
  watch: {
    component () {
      this.setComponent()
    }
  },
  /* computed() {

  }, */

  methods: {
    setComponent() {
      this.$emit("setComponent", {
        componentName: this.component,
        type: (this as any).availabelComponents[0].unit.name,
      });
    },
    getComponentDescr(slug) {
      if(!this.component) return ""
      return (this as any).availabelComponents.find(
        (el) => el.unit.slug === this.component
      ).unit.description;
    },
  },
});
</script>

<style lang="scss">
</style>