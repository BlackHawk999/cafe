<template>
  <v-row class="mt-3">
    <v-select
      v-for="item in Object.keys(fontsConfig)"
      v-model="fontsReference[item]"
      :key="fontsConfig[item].description"
      :items="fonts"
      :label="fontsConfig[item].description"
      item-text="name"
      class="ml-5"
    >
    </v-select>
  </v-row>
</template>

<script lang="ts">
import Vue from "vue";
export default Vue.extend({
  props: ["fonts", "fontsReference", "fontsConfig"],
  mounted() {
    console.log(this.fontsConfig);
    console.log(this.fontsReference)
  },
});
</script>

<style>
</style>