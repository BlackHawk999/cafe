<template>
  <v-row justify="center" align="center">
    <v-dialog class="white" v-model="show" width="80vw">
      <template v-slot:activator="{ on, attrs }">
        <v-hover v-slot="{ hover }">
          <a
            @click.prevent
            v-bind="attrs"
            v-on="on"
            href=""
            :class="{ 'grey--text lighten-5': hover }"
            class="text-body-2 text-decoration-none white--text"
            >Рецепты</a
          >
        </v-hover>
      </template>
      <div class="modal__wrapper">
        <v-btn class="close" @click="show = !show" icon color="grey">
          <v-icon>mdi-close</v-icon>
        </v-btn>
        <v-row>
          <h3 class="text-h6 text-left black--text">Запуск конфигов</h3>
        </v-row>

        <v-simple-table class="mt-15">
          <template v-slot:default>
            <thead>
              <tr>
                <th class="text-left">Запуск рецепта</th>
                <th class="text-left">Название созданого конфига</th>
                <th class="text-left">Дата создания</th>
                <th class="text-left">Запуск конфига в продакшен</th>
                <th class="text-left">Копировать конфиг</th>
                <th class="text-left">Удаления конфига</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="config in getReceipts" :key="config.name">
                <td>
                  <v-checkbox
                    :disabled="getReceipts.length === 1"
                    v-model="selected"
                    :value="config.name"
                  ></v-checkbox>
                </td>
                <td class="text-left">{{ config.name }}</td>
                <td class="text-left">{{ config.createdAt | formatDate }}</td>
                <td class="text-left">
                  <v-btn class="ma-2" icon>
                    <v-icon dark>mdi-play </v-icon>
                  </v-btn>
                </td>
                <td class="text-left">
                  <v-btn @click="copyConf(config.name)" class="ma-2" icon>
                    <v-icon dark> mdi-content-copy </v-icon>
                  </v-btn>
                </td>
                <td @click="deleteConf(config.name)" class="text-left">
                  <v-btn class="ma-2" icon>
                    <v-icon dark> mdi-delete-empty </v-icon>
                  </v-btn>
                </td>
              </tr>
            </tbody>
          </template>
        </v-simple-table>
        <!--  <v-row>
          <v-col cols="4">
            <p class="text-left">Название созданого конфига</p>
          </v-col>
          <v-col cols="8"> </v-col>
        </v-row> -->
        <!--  <v-row
          v-for="config in configs"
          :key="config.name"
          justify="space-between"
          class="mt-1"
        >
          <v-col cols="4">
            <p class="text-left">{{ config.name }}</p>
          </v-col>
          <v-col cols="8"> </v-col>
        </v-row> -->
        <v-row justify="space-between">
          <v-btn @click="show = false" color="primary" class="mt-10">
            Ок
          </v-btn>
          <Template></Template>
        </v-row>
      </div>
    </v-dialog>
  </v-row>
</template>

<script lang="ts">
import Vue from "vue";
import { mapGetters, mapMutations } from "vuex";
import { rebuild } from "@/services/api";
import Template from "./Template.vue";

export default Vue.extend({
  data(): any {
    return {
      show: false,
      selected: "",
    };
  },
  components: {
    Template,
  },
  computed: {
    // mix the getters into computed with object spread operator
    ...mapGetters([
      "getReceipts",
      "getSelectedReceipt"
      // ...
    ]),
  },
  watch: {
    show(val) { 
      if(!val) {
        if(this.getSelectedReceipt != this.selected) {
          this.selectRecept(this.selected)
          this.previewBuild()
        }
      }
    }
  },
  mounted() {
    this.selected = this.getSelectedReceipt;
  },
  methods: {
    ...mapMutations({
      addReceipt: "setReceipt",
      selectRecept: "setSelectedReceipt"
    }),
    copyConf(confName) {
      const config = { ...this.getReceipts.find((el) => el.name === confName) };
      while (this.getReceipts.find((el) => el.name === config.name)) {
        config.name = config.name + "(copy)";
      }
      config.createdAt = new Date();
      this.addReceipt({ receipt: config });
    },
    deleteConf(confName) {
      const config = { ...this.getReceipts.find((el) => el.name === confName) };
      this.addReceipt({ receipt: config, action: "remove" });
    },
    previewBuild() {
      const config = {
        ...this.getReceipts.find((el) => el.name === this.selected),
      };
      rebuild(config);
    },
  },
});
</script>>

<style>
</style>