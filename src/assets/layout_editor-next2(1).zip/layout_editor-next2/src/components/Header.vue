<template>
  <header class="purple darken-3">
    <v-container>
      <nav>
        <v-row>
          <v-col cols="2" sm="3" class="d-flex align-center">
            <router-link to="/" class="logo d-flex align-center">
              <img src="@/assets/images/logo.svg" alt="" />
            </router-link>
          </v-col>
          <v-col class="d-flex align-center" cols="2" offset="1">
            <div class="menu ml-auto d-flex  align-center">
              <div class="menu__item d-flex">
                <RedactConfig :configName="getSelectedReceipt" />
              </div>
              <div class="menu__item d-flex ml-10">
                <BuildConf/>
              </div>
              <!-- <div class="menu__item ml-5">
                <v-hover v-slot="{ hover }">
                  <router-link
                    :class="{ 'grey--text lighten-5': hover }"
                    class="text-body-2 text-decoration-none white--text"
                    to="/Home"
                    >Админка</router-link
                  >
                </v-hover>
              </div> -->
            </div>
          </v-col>
          <v-col cols="2" md="2" sm="3" offset-lg="3" offset-md="2" offset-sm="1" class="d-flex align-center">
            <!-- plain makes buttons translucent --> 
            <div class="d-flex">
              <v-btn
                @click="setDevice('tablet')"
                :plain="deviceType !== 'tablet' ? true : false"
                class=""
                text
                icon
                color="white"
              >
                <v-icon dense>mdi-tablet-ipad</v-icon>
              </v-btn>
              <v-btn
                @click="setDevice('mobile')"
                :plain="deviceType !== 'mobile' ? true : false"
                class="ml-1"
                text
                icon
                color="white"
              >
                <v-icon dense>mdi-cellphone-iphone</v-icon>
              </v-btn>
              <v-btn
                @click="setDevice('desktop')"
                :plain="deviceType !== 'desktop' ? true : false"
                class="ml-1"
                text
                icon
                color="white"
              >
                <v-icon dense>mdi-desktop-mac</v-icon>
              </v-btn>
            </div>
          </v-col>
          <v-col cols="1" lg="1" sm="2" class="d-flex align-center ml-auto">
            <router-link  to="/session-control" class="cabinet d-flex align-center ml-auto text-decoration-none">
              <v-btn class="ml-1" text icon color="white">
                <v-icon dense>mdi-account-circle-outline</v-icon>
              </v-btn>
              <div class="Caption white--text">User1</div>
            </router-link>
          </v-col>
        </v-row>
      </nav>
    </v-container>
  </header>
</template>


<script lang="ts">
import Vue from "vue";
import { mapGetters, mapActions } from "vuex";
import RedactConfig from "./modals/Template/RedactConfig.vue";
import BuildConf from "./modals/Template/BuildConf.vue";

export default Vue.extend({
  components: {
    RedactConfig,
    BuildConf
  },
  computed: {
    // mix the getters into computed with object spread operator
    ...mapGetters([
      "deviceType",
      "getReceipts",
      "getSelectedReceipt"
      // ...
    ]),
  },
  methods: {
    ...mapActions(["setDevice"]),
  },
});
</script>


<style lang="scss">
.menu {
  width: 100%;
}
.menu__item {
  a {
    transition: 0.3s ease;
  }
}
</style>
