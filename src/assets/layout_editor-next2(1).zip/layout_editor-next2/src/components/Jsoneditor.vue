<template>
  <v-container fluid>
    <v-responsive min-height="800" :aspect-ratio="16 / 9">
      <vue-json-editor
        v-model="json"
        :show-btns="false"
        :expandedOnStart="true"
        class="json-editor"
      ></vue-json-editor>
    </v-responsive>
    <div class="mt-3 d-flex justify-end">
      <v-btn @click="setJson" depressed color="primary">Save</v-btn>
    </div>
  </v-container>
</template>



<script lang="ts">
import Vue from "vue";
import vueJsonEditor from "vue-json-editor/vue-json-editor.vue";

// eslint-disable-next-line @typescript-eslint/no-explicit-any

export default Vue.extend({
  name: "Jsoneditor",
  components: {
    vueJsonEditor,
  },
  data() {
    return {
      json: this.ObjectJson,
    };
  },
  props: ["ObjectJson"],
  methods: {
    setJson() {
      this.$emit("setJson", this.json);
    },
  },
});
</script>


<style lang="scss">
.json-editor {
  height: 100%;
  .jsoneditor-vue {
    height: 100%;
  }
}
.ace_scroller {
  text-align: left;
} 
</style>