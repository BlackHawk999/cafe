import { deviceType } from '@/types'
 
export default interface State {
    token: string,
    port: number,
    device: deviceType,
    layouts: any,
    components: any,
    repConf: any,
    buildState: boolean,
    receipt: any,
    selectedReceipt: string
}