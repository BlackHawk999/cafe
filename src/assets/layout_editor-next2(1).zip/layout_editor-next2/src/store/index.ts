import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

import { State } from "@/models/index";
import { deviceType } from "@/types";

const gitCredentials = "gitlab+deploy-token-12:eEnAT5GzA4mXcXywVxWs";

export default new Vuex.Store<State>({
  state: {
    token: window.localStorage.getItem("token") || "",
    port: 0,
    device: "desktop",
    layouts: null,
    components: null,
    repConf: JSON.parse(
      window.localStorage.getItem("repository-configs") as any
    ) || {
      credentials: gitCredentials,
      aliases: {
        base_layouts: {
          git: `https://{$CREDENTIALS}@git.hm/webresto/factory/base_layouts.git`,
          rev: "staging"
        }
        /* masterLayouts: {
          git: `https://{$CREDENTIALS}@git.hm/webresto/factory/base_layouts.git`,
          rev: "a417e4f90c99e7364eec52f5e919dafb26a42429"
        } */
      }
    },
    buildState: true,
    receipt:
      JSON.parse(window.localStorage.getItem("user-configs") as any) || [],
    selectedReceipt:
      window.localStorage.getItem("selected-receipt") || "default"
  },
  mutations: {
    setDevice(state, device) {
      state.device = device;
    },
    setSelectedReceipt(state, selectedReceipt) {
      state.selectedReceipt = selectedReceipt;
      window.localStorage.setItem("selected-receipt", selectedReceipt);
    },
    setPort(state, port) {
      state.port = port;
    },
    setComponents(state, components) {
      state.components = components;
    },
    setLayouts(state, layouts) {
      state.layouts = layouts;
    },
    setToken(state, token) {
      state.token = token;
    },
    setRepConfig(state, config) {
      state.repConf = config;
      window.localStorage.setItem("repository-configs", JSON.stringify(config));
    },
    setBuildState(state, config) {
      state.buildState = config;
    },
    clearReceipts(state) {
      state.receipt = []
    },  
    setReceipt(state, { receipt, action }) {
      action = action || "add";
      console.log(action);
      if (action === "add") {
        state.receipt.unshift(receipt);
      }
      if (action === "update") {
        state.receipt[
          state.receipt.findIndex(el => el.name === receipt.name)
        ] = receipt;
      }
      if (action === "remove") {
        if (state.receipt.length === 1) {
          Vue.$toast.open({
            message: "Ony one receipt left",
            type: "error"
            // all of other options may go here
          });
          return;
        }
        console.log(state.receipt.findIndex(el => el.name === receipt.name));
        state.receipt.splice(
          state.receipt.findIndex(el => el.name === receipt.name),
          1
        );
      }
      state.receipt = [...state.receipt];
      window.localStorage.setItem(
        "user-configs",
        JSON.stringify(state.receipt)
      );
    }
  },
  getters: {
    deviceType: state => {
      return state.device;
    },
    getSelectedReceipt: state => {
      return state.selectedReceipt;
    },
    getComponents: state => {
      return state.components;
    },
    getLayouts: state => {
      return state.layouts;
    },
    getToken: state => {
      return state.token;
    },
    getPort: state => {
      return state.port;
    },
    getRepConf: state => {
      return state.repConf;
    },
    getBuildState: state => {
      return state.buildState;
    },
    getReceipts: state => {
      return state.receipt;
    }
  },
  actions: {
    setDevice({ commit }, device: deviceType) {
      commit("setDevice", device);
    },
    setComponents({ commit }, components: any) {
      commit("setComponents", components);
    },
    setLayouts({ commit }, layouts: any) {
      commit("setLayouts", layouts);
    },
    setToken({ commit }, token: string) {
      window.localStorage.setItem("token", token);
      commit("setToken", token);
    },
    setPort({ commit }, port: number) {
      commit("setPort", port);
    },
    setRepConfig({ commit }, config: any) {
      commit("setRepConfig", config);
    }
  },
  modules: {}
});
