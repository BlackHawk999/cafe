type deviceType = 'tablet' | 'mobile' | 'desktop'

export {
    deviceType
}